# 🌾 AgriBusiness.pk — Pakistan's Premier Agri-Tech Ecosystem

> **AgriBusiness** is a comprehensive, production-ready agricultural marketplace, clinical advisory, and professional network platform engineered specifically for Pakistan's farming communities, agronomists, millers, livestock keepers, and agribusiness enterprises.

---

## 🌟 Key Platform Pillars & Companion Apps

### 1. 🚜 **Agri Biz (B2B Marketplace & Classifieds)** — `/apps/agri-biz`
- **Free Classified Trading Floor:** Buy and sell bulk crops (wheat, basmati rice, cotton), farm machinery (tractors, combine harvesters), solar tubewells, and certified fertilizers with transparent PKR pricing.
- **Interactive Post Listing Modal:** Post items with photos, quantity, unit, mandi location, and direct WhatsApp contact.
- **Dynamic Category & Search Filters:** Filter by Commodities, Machinery, Inputs, and Regional Mandis.

### 2. 🐾 **Animal Clinic (Veterinary Telehealth)** — `/apps/animal-clinic`
- **Livestock & Herd Healthcare:** Telehealth platform for dairy cattle, buffaloes, goats, and poultry.
- **Multi-Format Clinical Case Posting:** Farmers post disease symptoms using photos, audio/voice notes, and video evidence.
- **Partner University Advisory:** Certified veterinary prescriptions and peer advice from experienced livestock farmers.

### 3. 🌱 **Plant Clinic (AI Crop Doctor)** — `/apps/plant-clinic`
- **Instant Disease Diagnosis:** Photo-based visual check for leaf blights, fungal spots, rust, and pest attacks on wheat, citrus, mango, cotton, and vegetables.
- **Qualified Agronomist Advisory:** Verified agronomists evaluate soil chemistry and provide tailored crop recovery plans.

### 4. 🎓 **Agri-Tech Academy (Education Hub)** — `/apps/education`
- **Certified Agronomy Masterclasses:** Video courses on precision drip irrigation, greenhouse setup, and organic soil management taught by University of Agriculture faculty.

### 5. 💼 **Projects & RFP Bidding Board** — `/projects`
- **Consulting & Equipment RFPs:** Post agricultural requirements (e.g., 50-Acre Citrus Drip Design, Harvester Rental) with PKR budgets.
- **Bidding Platform:** Verified agronomists and contractors submit bids and project briefs with escrow safeguards.

### 6. 🌐 **Verified 24-Sector Expert Network** — `/search`
- Connect with verified consultants, companies, students, and farmers across **24 Official Industry Disciplines**.
- In-depth member dossiers with ratings, contact channels, and credential verification.

### 7. 📈 **Live Kisan Mandi Ticker**
- Real-time commodity market prices across Faisalabad, Multan, Sargodha, Rahim Yar Khan, and Sahiwal.

---

## 🛠️ Technology Stack

| Layer | Technology |
|---|---|
| **Frontend Framework** | React 19 + TypeScript + TanStack Start (SSR) |
| **Routing** | TanStack React Router (Type-Safe Route Tree) |
| **Styling & Design System** | Tailwind CSS v4 + Material Symbols + Framer Motion |
| **Database & Auth** | Supabase (PostgreSQL 15 + Row Level Security + GoTrue Auth) |
| **State & Server Fns** | TanStack Query + Supabase JS Client + Local Storage Fallbacks |
| **Packaging & Build** | Vite 8 + Nitro (Cloudflare / Node Server Engine) |

---

## 📂 Project Structure

```
├── public/                     # Static assets, manifests, robots.txt
├── scripts/                    # Database verification & test scripts
│   ├── generate_complete_sql.mjs
│   ├── test_anon_auth.mjs
│   └── verify_live_db.mjs
├── src/
│   ├── components/
│   │   ├── home/               # Hero, EcosystemApps, AppHub, CategoryGrid, Pricing
│   │   ├── layout/             # Top Navbar, Footer, Language Switcher
│   │   ├── shared/             # ProfileCard, RateTicker, WhatsAppButton, Skeletons
│   │   └── ui/                 # Accessible UI primitives (dialogs, cards, forms)
│   ├── lib/
│   │   ├── format.ts           # PKR currency format, CNIC & Pakistani phone validator
│   │   ├── i18n.tsx            # English & Urdu (اردو) translation dictionary
│   │   ├── supabase.ts         # Supabase client singleton & auto-recovery
│   │   └── utils.ts            # Class merging and utility helpers
│   ├── routes/
│   │   ├── index.tsx           # Homepage with Mandi ticker & apps suite
│   │   ├── apps/
│   │   │   ├── index.tsx       # Dedicated Companion Apps Overview
│   │   │   ├── agri-biz.tsx    # B2B Trading floor & product posting
│   │   │   ├── animal-clinic.tsx # Livestock clinic & telehealth cases
│   │   │   ├── plant-clinic.tsx  # Crop disease diagnosis & advice
│   │   │   └── education.tsx   # Agri-Tech Academy & video courses
│   │   ├── categories/         # Master 26-category taxonomy & detail hubs
│   │   ├── dashboard.tsx       # Member workspace & listing manager
│   │   ├── onboarding.tsx      # Dual Sign-Up & Log-In with 24 Disciplines
│   │   ├── profile.$id.tsx     # Dynamic public/private profile & in-place editor
│   │   ├── projects.tsx        # Project board & RFP submission modal
│   │   ├── search.tsx          # 24-sector verified directory query
│   │   └── admin/index.tsx     # Platform governance & moderation core
└── supabase/
    ├── COMPLETE_DATABASE_SETUP.sql # 2,446-line Master DB Schema & Seed Script
    └── migrations/             # Incremental Postgres migration files (00 - 08)
```

---

## 🚀 Getting Started Locally

### 1. Prerequisites
- **Node.js**: `v20.x` or higher
- **npm** or **bun**

### 2. Clone and Install Dependencies
```bash
git clone https://github.com/mrjawadhere/agribusiness2.git
cd agribusiness2
npm install
```

### 3. Environment Configuration
Create a `.env` file in the root directory (or use `.env.example`):
```env
# Supabase Configuration
SUPABASE_URL=https://yholetgmaexmcvupmwmn.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_SUPABASE_URL=https://yholetgmaexmcvupmwmn.supabase.co
VITE_SUPABASE_ANON_KEY=sb_publishable_Q7f-82AxY673B2CvzJxt5g_Xcki060E
```

### 4. Run Development Server
```bash
npm run dev
```
Open your browser at **`http://localhost:3000`** (or active Vite port).

### 5. Production Build
```bash
npm run build
```

---

## 🗄️ Database Setup & Verification

The repository includes the complete master script: [`supabase/COMPLETE_DATABASE_SETUP.sql`](supabase/COMPLETE_DATABASE_SETUP.sql).

### Key Tables in Live Database:
- `public.profiles`: User profiles, verified status, 24 disciplines, CNIC, and phone numbers.
- `public.categories`: 26 primary and secondary agricultural classifications.
- `public.listings`: B2B marketplace commodity and machinery lots.
- `public.projects`: Project RFPs, precision engineering requirements, and budgets.
- `public.market_rates`: Daily mandi commodity rates (Wheat, Basmati, Cotton, Sugarcane, Fertilizers).
- `public.problem_posts`: Plant and animal clinic diagnoses and symptom records.

### Verify Live Database:
```bash
node scripts/verify_live_db.mjs
```

---

## 🏷️ Official 24 Agricultural Disciplines
Integrated across registration, directory filters, and member profiles:
1. Agricultural Engineering and Technology
2. Agribusiness Family Care
3. Agriculture
4. Basic Sciences
5. Business Management Sciences
6. Computer Science
7. Construction
8. Education
9. Electronic and Print Media
10. Engineering (Civil, Mechanical, Electric and Electronics)
11. Food Science and Technology
12. Health and Diagnostics
13. Horticultural Sciences
14. Information Technology
15. Lab Equipments and Chemicals
16. Law and Lawyers
17. Marketing (General Order Supplies)
18. Oil Industry
19. Poultry Science / Animal Science
20. Real-Estate
21. Sugar Industry
22. Textile Industry
23. Veterinary Science (DVM)
24. Others

---

## 📄 License & Governance
Developed for **AgriBusiness Pakistan**. All rights reserved.